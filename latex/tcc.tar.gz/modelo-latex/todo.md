[x] - introduce neural networks
[x] - introduce hidden layers and loss function 
[x] - introduce back progapagation
[] - talk about how we tried to approximate a neural network 
[] - talk about the simplex approximation for continuity
[] - talk about how exponential it can get and limitations
[] - talk about experiments with XOR network
[] - do experiments
[] - show experiments
